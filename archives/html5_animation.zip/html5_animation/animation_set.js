//遮罩圖檔的路徑
maskFilename = "assets/animation-mask.png";

//動畫圖檔的路徑清單
menu_items = [ 
			"assets/animation-frames.png"
			, "assets/animation-frames-1.png"
			, "assets/animation-frames-2.png"
			, "assets/animation-frames-3.png"
			, "assets/animation-frames-4.png"
			, "assets/animation-frames-5.png"
			, "assets/animation-frames-6.png"
];

//圖片來源的網址
sourceURL = "https://openclipart.org/";