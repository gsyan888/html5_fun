optionsTotal = 9;		//共有幾個選項
optionWidth = 100;		//每個選項的寬度
optionHeight = 100;		//每個選項的高度
optionColTotal = 3;		//一列有幾個選項

/**
 * 遊戲說明的設定
 */ 

 //標題 
intro_title = '比賽說明';

//說明文字
intro_message = '一局定輸贏：投出 3K 可以贏得比賽；如果被得分就得重新挑戰。加油！';

//按鈕上的文字
intro_button_text = '開始投球';

menuSettingFilename = 'baseball_menu_set.js';	//選單設定檔檔名

scoreToAdd = 10;		//答對時加幾分
scoreToMinus = -10;		//答錯時扣幾分

