﻿

menu_title =  "量詞大挑戰";

datafolder = "data"

menu_items = new Array(
  "量詞找名詞生手級,b01-1.js"
, "量詞找名詞入門級,b01-2.js"
, "量詞找名詞高手級,b01-3.js"
, "名詞找量詞生手級,b02-1.js"
, "名詞找量詞入門級,b02-2.js"
, "名詞找量詞高手級,b02-3.js"
);
