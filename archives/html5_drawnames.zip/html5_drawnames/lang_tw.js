//*******************************************
//
// This file will load by  drawnames.js
//
//******************************************

//******************************************
// 訊息內容
//******************************************

cfg_messageSettingCaption = '設定'; //'Setting';
cfg_messageStagesDescription = new Array('抽籤步驟', '1.輸入姓名', '2.設定人數', '3.確認資料', '4.開始抽籤');
cfg_messageStage1Caption = '設定：輸入姓名';
cfg_messageStage2Caption = '設定：輸入名額';
cfg_messageStage3Caption = '確認名單及名額';
cfg_messageStage4Caption = '進行抽籤';