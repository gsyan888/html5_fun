﻿//每題有幾個選項
numberOfOptions = 4;

//每列最多可以有幾個選項
numberOfOptionsPerRow = 2;	

//是否自動顯示選項供作答(預設為 true; false 時需按[開始作答]鈕才會出現選項)
auto_show_options = true;

//每回合抽幾題題目
numberOfQuestionsPerRound = 10;

//出題時選擇題目的方式 true:亂數選題  false:按題庫順序
select_questions_in_random = true; 


//聲音檔路徑的前置網址
//也就是會為 questionLines 的左欄前面自動加上的字串
//
// English 1200
soundBaseURL = 'https://gsyan888.github.io/english1200/';

//語音播放的速度(使用大於 0 的數字。例如:1.0 正常, 0.75 較慢速, 0.5 慢速, 1.5 快速, 2.0 兩倍速)
audioPlaybackRate = 1.0; 

//語音自動播放的次數。 
audioAutoPlayLoop = 1;

//隔多久重播(單位秒)
audioAutoPlayDelay = 0;


//是否使用 TTS 的語音
tts_enabled = true;

//----------------
//Google TTS 文字轉語音的設定
//----------------
tts_language = 'en';  // en : 英語,   zh_tw : 中文
tts_speed = 0.3;  //語音的速度 0 ~ 1 (可用小數)
tts_base_url = 'https://translate.google.com/translate_tts?ie=UTF-8&tl='+tts_language+'&client=tw-ob&ttsspeed='+tts_speed+'&q=';


//題庫
//欄位分隔符號為兩個井字號(##)
seperator = '##';

//左欄為聲音檔路徑
//右欄為中文
questionLines = function(){/*--這一行請勿更改--
cat##貓咪
chicken##雞
cow##牛
dog##狗
egg##蛋
horse##馬
monkey##猴子
-----*/}.toString().replace(/\r/g,"").slice("function(){/*--這一行請勿更改--".length+1,-9);
