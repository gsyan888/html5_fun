﻿//
//開始比賽前, 說明對話框的說明文字
//
helpText = "請找出算式的答案。";


denominatorMin = 2;	//分母最小
denominatorMax = 9;	//分母最大

numeratorMaxScale = 2;	//分子最大是分母的幾倍


//基本設定
optionsTotal = 9;		//共有幾個選項
optionWidth = 100;		//每個選項的寬度
optionHeight = 100;		//每個選項的高度
optionColTotal = 3;		//一列有幾個選項

timerStartSeconds = 30;	//計時器由幾秒開始倒數


/******************************************************************
 以下為程式碼, 不要更動
 ******************************************************************/
getOneQuestion = function(tools) {
	//分數相加
	
	//抽出一個分母
	var tempRandom = tools.makeRandomIndex(denominatorMin, denominatorMax);
	var r = Math.floor(Math.random()*tempRandom.length);
	var denominator = tempRandom[r];	//分母
	
	//抽出二個分子
	var tempRandom = tools.makeRandomIndex(1, Math.round(denominator*numeratorMaxScale));
	var r = Math.floor(Math.random()*tempRandom.length);
	var numerator1 = tempRandom[r];	//分子1
	var r = Math.floor(Math.random()*tempRandom.length);
	var numerator2 = tempRandom[r];	//分子2
	
	//組合成題幹
	var question = '';		//題幹
	// a+b/c => [a:b:c]
	var a = Math.floor(numerator1/denominator);
	var b = numerator1%denominator;
	if(b != 0) {
		if(Math.random()*10 > 5) {	//帶分數|假分數機率各半
			question += '['+a+':'+b+':'+denominator+']';	//帶分數
		} else {
			question += '['+numerator1+':'+denominator+']';	//假分數
		}
	} else {	//整數
		question += a;
	}

	question += '+';
	
	var a = Math.floor(numerator2/denominator);
	var b = numerator2%denominator;
	if(b != 0) {
		if(Math.random()*10 > 5) {	//帶分數|假分數機率各半
			question += '['+a+':'+b+':'+denominator+']';
		} else {
			question += '['+numerator2+':'+denominator+']';	//假分數
		}
	} else {
		question += a;
	}
	question += '= ?';
	
	//計算答案
	var answer = '';
	var numerator = numerator1 + numerator2;
	var a = Math.floor(numerator/denominator);
	var b = numerator%denominator;
	if(b != 0) {
		answer += '['+a+':'+b+':'+denominator+']';
	} else {
		answer += a;
	}
	
	//製作其它非正解的選項
	if(numerator-1 < 5) {
		var min = 1-numerator;
	} else {
		var min = -5;
	}
	//以亂數產生要由答案再加減多少
	var nRandom = tools.makeRandomIndex(min, 9);	//其它選項比解答加減多少(用亂數排)
	for(var j=0; j<nRandom.length; j++) {
		if(nRandom[j] == 0) {
			nRandom.splice(j,1);	//把零的去掉, 以免同一個答案出現兩次
		}
	}
	/*
		a:c:b,
	*/
	
	var op = new Object();
	op.type = '分數';
	op.optionsOK = new Array();
	op.optionsNG = new Array();
	
	op.question = question;
	op.optionsOK[0] = answer;
	for(var i=0; i<nRandom.length; i++) {
		var ng = '';
		var n = numerator + nRandom[i];
		var a = Math.floor(n/denominator);
		var b = n%denominator;
		if(b != 0) {
			ng += '['+a+':'+b+':'+denominator+']';
		} else {
			ng += a;
		}	
		op.optionsNG[i] = ng;
	}
	return op;
}
