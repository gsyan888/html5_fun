menu_title='捉鬼特攻隊';
menu_items = new Array(
  "量詞找名詞生手級,data/b01-1.js"
, "量詞找名詞入門級,data/b01-2.js"
, "量詞找名詞高手級,data/b01-3.js"
, "名詞找量詞生手級,data/b02-1.js"
, "名詞找量詞入門級,data/b02-2.js"
, "名詞找量詞高手級,data/b02-3.js"

,  "九九乘法,data/9x9.js"
, "除法入門級,data/9x9-divide.js"  

, "分數加法入門級,data/fraction_add.js"
, "分數加法高手級,data/fraction_add2.js"
, "分數減法,data/fraction_sub.js"
, "分數乘法入門級,data/fraction_multiplication-1.js"

);
