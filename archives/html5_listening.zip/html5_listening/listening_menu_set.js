﻿menu_title='聽音辨字六選一';
menu_items = new Array(
  '範例(.js),sample_listening_set.js'
, '範例(.txt),sample_listening_set.txt'
, '範例(中文測試),sample_chinese_set.js'
, '範例(網路的設定),http://mail.lsps.tp.edu.tw/~gsyan/works/flash/listening/listening2_set.txt'
);
