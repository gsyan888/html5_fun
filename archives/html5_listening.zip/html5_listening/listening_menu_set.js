﻿menu_title='聽音辨字六選一';
menu_items = new Array(
  '範例1:綜合展示,questions-set-1.js'
,  '範例2:只放圖片檔名,questions-set-2.js'
,  '範例3:只放語音檔名、資料夾chinese,questions-set-3.js'
);
