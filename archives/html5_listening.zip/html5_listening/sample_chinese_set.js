﻿//-------------------------------
//
//設定參數
//
var URIformatVars = function(){/*--這一行請勿更改--
&title=中文測試(.js)&
&show_text=no&
&file_list=sample_chinese_mp3_list.js&
&images_folder=chinese&
&mp3_folder=chinese&
&col=3&
&questionsToAnswer=5&
&scoreToAdd=10,8,6,4,2,0&
&logger=&
-----*/}.toString().replace(/\r/g,"").slice("function(){/*--這一行請勿更改--".length+1,-9);

