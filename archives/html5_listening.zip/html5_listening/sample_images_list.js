﻿var URIformatVars = function(){/*--這一行請勿更改--
cat.png
chicken.png
cow.png
dog.png
egg.png
horse.png
monkey.png
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9);
