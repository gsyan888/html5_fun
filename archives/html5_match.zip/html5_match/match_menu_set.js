menu_title='TPET 對對碰選單';
menu_items = new Array(
  '不蓋牌,match_set.js'
, '記憶大考驗,match_set_memory.js'
, '九九乘法,match_set_9x9.js'
);
