title = '九九乘法對對碰(8,9)';
font = '標楷體';
maxCol = 6;
scoreAdd = 100;
scoreMinus = 150;
memoryMode = 'no';
momorySeconds = 10;
cards= new Array(
  '9x1,9'
, '9x2,18'
, '9x3,27'
, '9x4,36'
, '9x5,45'
, '9x6,54'
, '9x7,63'
, '9x8,72'
, '9x9,81'
, '8x1,8'
, '8x2,16'
, '8x3,24'
, '8x4,32'
, '8x5,40'
, '8x6,48'
, '8x7,56'
, '8x8,64'
, '8x9,72'
);