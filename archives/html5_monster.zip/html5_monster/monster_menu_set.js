﻿menu_title = "詞語大挑戰";		//選單標題(字數不要超過五個字)

//
//選單：以逗號當分隔
//		前面為選單項目名稱，
//		後面為題庫設定檔檔名
//
menu_items = new Array(
  "心緒類語詞:初級篇,monster_set_basic.js"
, "心緒類語詞:高級篇,monster_set_advance.js"
);

