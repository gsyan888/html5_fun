//
photoFolder = 'photo';			//放照片的目錄名稱
photoNameExtension = '.jpg';	//照片的副檔名

//sound_data_filename = 'sound_data_boy.js';   //男生語音
sound_data_filename = 'sound_data_girl.js';  //女生語音

boymin = 1;		//男生最小號碼
boymax = 15;		//男生最大號碼

girlmin = 21;	//女生最小號碼
girlmax = 35;	//女生最大號碼

excluded = '';	//除外的號碼:用逗號分隔

mixing= "N";	//男女是否混合: Y 不分男女, N 一男一女
