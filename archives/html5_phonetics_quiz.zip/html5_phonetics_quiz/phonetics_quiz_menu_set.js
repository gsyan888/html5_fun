menu_title='注音高手';
menu_items = new Array(
 '例1:不選國字,sample-set-1.js'
,'例2:要選國字,sample-set-2.js'
);
