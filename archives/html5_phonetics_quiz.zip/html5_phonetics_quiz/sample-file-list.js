﻿var URIformatVars = function(){/*--這一行請勿更改--
小狗.mp3
小狗.png
山羊.mp3
帽子.mp3
帽子.png
斑馬.mp3
斑馬.png
杯子.mp3
杯子.png
被子.mp3
被子.png
貓咪.mp3
貓咪.png
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9);