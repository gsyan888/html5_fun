﻿var URIformatVars = function(){/*--這一行請勿更改--
&title=注音高手範例1:不選字&
&phonetics_table_filename=phonetab.js&
&show_character=yes&
&character_select_enabled=no&
&random_order_enabled=yes&
&questions_to_answer=5&
&data_folder_name=data&
&file_list=sample-file-list.js&
&logger_url=&
-----*/}.toString().replace(/\r/g,"").slice("function(){/*--這一行請勿更改--".length+1,-9);