menu_title='PK大賽';
menu_items = new Array(
  "九九乘法,data/9x9.js"
  
, "加法(一位數加一位數),data/math-add-1-1.js"
, "加法(兩位數加一位數),data/math-add-2-1.js"
, "加法(兩位數加兩位數),data/math-add-2-2.js"
, "減法(一位數減一位數),data/math-sub-1-1.js"
, "減法(兩位數減一位數),data/math-sub-2-1.js"
, "減法(兩位數減兩位數),data/math-sub-2-2.js"
  
  
, "除法入門級,data/9x9-divide.js"  

, "二位小數加法,data/decimal_add.js"
, "二位小數減法,data/decimal_sub.js"

, "乘法(整十、整百倍),data/9x900.js"
, "乘法(整十的整十倍),data/90x90.js"


, "分數加法入門級,data/fraction_add.js"
, "分數加法高手級,data/fraction_add2.js"
, "分數減法,data/fraction_sub.js"
, "分數乘法入門級,data/fraction_multiplication-1.js"

, "量詞找名詞生手級,data/b01-1.js"
, "量詞找名詞入門級,data/b01-2.js"
, "量詞找名詞高手級,data/b01-3.js"
, "名詞找量詞生手級,data/b02-1.js"
, "名詞找量詞入門級,data/b02-2.js"
, "名詞找量詞高手級,data/b02-3.js"

, "範例1,samples/sample-1.js"
, "範例2-1,samples/sample-2-1.js"
, "範例2-2,samples/sample-2-2.js"
, "範例2-3,samples/sample-2-3.js"
, "範例3,samples/sample-3.js"
, "範例4,samples/sample-4.js"


);
