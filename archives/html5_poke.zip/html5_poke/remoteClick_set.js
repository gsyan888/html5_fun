//接收控制的程式
appUrl = 'html5_poke.html';

//include Achex SDKs
includeSDKs = [
	'https://achex.ca/js/JQ.js'
	,'https://achex.ca/js/jquery.achex.js'
];

