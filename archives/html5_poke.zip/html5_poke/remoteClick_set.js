//接收控制的程式
appUrl = 'html5_poke.html';

//include Achex SDKs
includeSDKs = [
	'http://achex.ca/js/JQ.js'
	,'http://achex.ca/js/jquery.achex.js'
];

