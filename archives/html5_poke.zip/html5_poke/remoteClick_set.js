///
//接收控制碼的頁面, 連線前會重導至這個頁面
//可以是本機的, 或是遠端的
//
appUrl = 'html5_poke.html';

//
//遙控器的網址
//如果是遠距用的, 一定要放在網路上, 別人才能存取
//
remoteClickUrl = 'https://gsyan888.github.io/html5_fun/html5_remoteClick/html5_remoteClick.html';

//
//include Achex SDKs
//
includeSDKs = [
	'https://achex.ca/js/JQ.js'
	,'https://achex.ca/js/jquery.achex.js'
];

