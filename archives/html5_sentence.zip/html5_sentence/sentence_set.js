﻿
//題庫設定檔的檔名(*.js)
question_set_filename = "question_set.js";

//字卡的相關設定
card_border = 1;					//邊框粗細
card_border_color = "#a52a2a";		//邊框顏色
card_caption_color = "#886600";		//標題字的顏色
card_text_color = "#000000";		//第一面字的顏色
card_back_text_color = "#6F4E37";	//第二面字的顏色

//背景顏色
card_background_color = new Array(
"#FFB7DD" , "#FFCCCC" , "#FFC8B4" , "#FFDDAA" ,
"#ffefd5" , "#6495ed" , "#00ff7f" , "#b8860b" , 
"#ee82ee"
);

