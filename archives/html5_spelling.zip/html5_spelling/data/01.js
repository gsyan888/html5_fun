var URIformatVars = function(){/*--這一行請勿更改--
line=2;dog,小狗;cat,貓;cow,牛;mouse,老鼠;chicken,雞,mp3/chicken.mp3;monkey,猴子,mp3/monkey.mp3;tiger,老虎;goat,羊;horse,馬;hippo,河馬&
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9);