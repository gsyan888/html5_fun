var URIformatVars = function(){/*--這一行請勿更改--
&line=2;violin,小提琴;piano,鋼琴;recorder,直笛;flute,橫笛;trumpet,小喇叭;triangle,三角鐵;guitar,吉他;drum,鼓&
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9);
