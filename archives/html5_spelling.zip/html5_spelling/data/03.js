﻿var URIformatVars = function(){/*--這一行請勿更改--
line=1;angry,生氣,mp3/angry.mp3;smile,微笑,mp3/smile.mp3;cry,哭,mp3/cry.mp3&
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9);