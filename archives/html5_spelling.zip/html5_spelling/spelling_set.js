﻿var URIformatVars = function(){/*--這一行請勿更改--
&title=單字高手&
&number_enabled=no&
&logger_url=&
&datafolder=data&
&menu=
單字高手:動物(限時60秒),01.js
單字高手:樂器,02.js
單字高手:表情,03.js
&
-----*/}.toString().slice("function(){/*--這一行請勿更改--".length+2,-9);
