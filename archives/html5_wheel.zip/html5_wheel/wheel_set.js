//轉輪上的項目
wheel_fontSize = 24;	//字體大小
wheel_question_fontSize = 60; //問題的字體大小
wheel_questions = new Array(
//------------------------------------下一行開始增加項目
  '純文字題;eye 的中文是什麼？'
, '純圖片題;sample/cat.png'
, '純聲音題;sample/eye.mp3'
, '文字+圖片題;圖片中的動物英文是什麼？#sample/cat.png'
, '文字+聲音題;聽聽看，它的中文該怎麼說？#sample/eye.mp3'
, '文字+圖片+聲音;聽聽看，並在圖中出找出它說的部位#sample/cat.png#sample/eye.mp3'
//------------------------------------結束,以下請勿修改
);