scoreToAdd = 10;		//答對時加幾分
scoreToMinus = -10;	//答錯時扣幾分
menuSettingFilename = 'basketball_menu_set.js';	//選單設定檔檔名

